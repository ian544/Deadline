package mobiledev.unb.ca.lab4skeleton

object Constants {
    // Strings will serve as keys when saving state between activities
    const val NOTIFICATION_CHANNEL_ID = "mobiledev.unb.ca.lab4skeleton.channel_01"
    const val NOTIFICATION_REQUEST_ID = 1
}
