package ca.unb.mobiledev.deadlinesketch

data class Task(val dueDate: String, val title: String, val description: String) {}


