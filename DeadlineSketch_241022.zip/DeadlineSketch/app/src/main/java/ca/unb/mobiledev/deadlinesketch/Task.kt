package ca.unb.mobiledev.deadlinesketch

data class Task(val dueDate: String?, val name: String?, val description: String? = null) {}


