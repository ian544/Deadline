package com.example.databaseset_up.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.databaseset_up.DAO.NotificationDao
import com.example.databaseset_up.DAO.TagDao
import com.example.databaseset_up.DAO.TaskDao
import com.example.databaseset_up.DAO.listDao
import com.example.databaseset_up.Entity.list
import com.example.databaseset_up.Entity.Task
import com.example.databaseset_up.Entity.Tag
import com.example.databaseset_up.Entity.Notification
import kotlinx.coroutines.CoroutineScope
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Database(entities = [list::class, Task::class, Tag::class, Notification::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun listDao(): listDao
    abstract fun notificationDao(): NotificationDao
    abstract fun taskDao(): TaskDao
    abstract fun tagDao(): TagDao

    companion object{
        @Volatile
        private var INSTANCE: AppDatabase ?= null
        private const val NUM_THREADS = 4
        val databaseWriterExecutor: ExecutorService = Executors.newFixedThreadPool(NUM_THREADS)


        fun getDatabase(context: Context): AppDatabase {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "Deadline_DB").build()
                INSTANCE = instance
                return instance
            }
        }
    }
}