package com.example.databaseset_up.DAO

import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.databaseset_up.Entity.Tag

interface TagDao {
    @Query("SELECT * from task_table, tag_table WHERE task_id = :task_ID")
    fun listAllTagsFromTask(task_ID: Int): List<Tag>

    @Update(Tag::class)
    fun changeTag(task: Tag)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertTag(task: Tag)

    @Delete
    infix fun deleteTag(task: Tag): Int

}