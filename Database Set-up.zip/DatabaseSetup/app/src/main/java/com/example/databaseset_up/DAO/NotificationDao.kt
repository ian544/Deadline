package com.example.databaseset_up.DAO

import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.databaseset_up.Entity.Notification

interface NotificationDao {
    @Query("SELECT * from task_table, notification_table WHERE task_id = :task_ID")
    fun listAllNotificationsFromTask(task_ID: Int): List<Notification>

    @Update(Notification::class)
    fun changeNotification(notification: Notification)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertNotification(notification: Notification)

    @Delete
    infix fun deleteNotification(notification: Notification): Int

}