package com.example.databaseset_up.Repo

import android.app.Application
import com.example.databaseset_up.DAO.NotificationDao
import com.example.databaseset_up.DAO.TagDao
import com.example.databaseset_up.DAO.TaskDao
import com.example.databaseset_up.DAO.listDao
import com.example.databaseset_up.Entity.Notification
import com.example.databaseset_up.Entity.Tag
import com.example.databaseset_up.Entity.Task
import com.example.databaseset_up.Entity.list
import com.example.databaseset_up.db.AppDatabase
import com.example.databaseset_up.db.AppDatabase.Companion.getDatabase
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

class dbRepo(application: Application) {
    private val list_dao: listDao = getDatabase(application).listDao()
    private val notif_Dao: NotificationDao = getDatabase(application).notificationDao()
    private val tag_Dao: TagDao = getDatabase(application).tagDao()
    private val task_Dao: TaskDao = getDatabase(application).taskDao()

    fun insertList(lName: String){
        var list = list()
        list.list_name = lName
        AppDatabase.databaseWriterExecutor.execute { list_dao.insertList(list) }
    }

    fun insertNotif(nName: String, nDescrip: String, taskID: Int, actTime: Long, isRec: Boolean, recTime: Long){
        var notif = Notification()
        notif.notification_name = nName
        notif.notification_description = nDescrip
        notif.task_id = taskID
        notif.activation_time = actTime
        notif.reaccuring_time = recTime
        notif.isReacurring = isRec
        AppDatabase.databaseWriterExecutor.execute { notif_Dao.insertNotification(notif) }
    }

    fun insertTask(lID: Int, tName: String, tDescrip: String, dueDate: Long, actDate: Long, prio: Int){
        var task = Task()
        task.list_id = lID
        task.title = tName
        task.description = tDescrip
        task.due_date = dueDate
        task.activate_time = actDate
        task.priority = prio
        AppDatabase.databaseWriterExecutor.execute { task_Dao.insertTask(task) }
    }

    fun insertTag(tName: String, tID: Int){
        var tag = Tag()
        tag.tag_name = tName
        tag.task_id = tID;
        AppDatabase.databaseWriterExecutor.execute { tag_Dao.insertTag(tag) }
    }

    fun getList(): List<list>{
        val dataReadFuture: Future<List<list>> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                list_dao.listAllLists()
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            emptyList()
        }
        catch(e: InterruptedException){
            emptyList()
        }
    }

    fun getTask(list_id: Int): List<Task>{
        val dataReadFuture: Future<List<Task>> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                task_Dao.listAllTasksFromList(list_id)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            emptyList()
        }
        catch(e: InterruptedException){
            emptyList()
        }
    }

    fun getNotif(task_id: Int): List<Notification>{
        val dataReadFuture: Future<List<Notification>> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                notif_Dao.listAllNotificationsFromTask(task_id)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            emptyList()
        }
        catch(e: InterruptedException){
            emptyList()
        }
    }

    fun getTag(task_id: Int): List<Tag>{
        val dataReadFuture: Future<List<Tag>> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                tag_Dao.listAllTagsFromTask(task_id)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            emptyList()
        }
        catch(e: InterruptedException){
            emptyList()
        }
    }
    fun updateList(list: list){
        AppDatabase.databaseWriterExecutor.execute { list_dao.updateList(list) }
    }
    fun updateNotif(notification: Notification){
        AppDatabase.databaseWriterExecutor.execute { notif_Dao.changeNotification(notification) }
    }
    fun updateTask(task: Task){
        AppDatabase.databaseWriterExecutor.execute { task_Dao.changeTask(task) }
    }
    fun updateTag(tag: Tag){
        AppDatabase.databaseWriterExecutor.execute { tag_Dao.changeTag(tag) }
    }

    fun deleteList(list: list): Int{
        val dataReadFuture: Future<int> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                list_dao.deleteList(list)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            -1
        }
        catch(e: InterruptedException){
            -1
        }
    }

    fun deleteTask(task: Task): Int{
        val dataReadFuture: Future<Int> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                task_Dao.deleteTask(task)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            -1
        }
        catch(e: InterruptedException){
            -1
        }
    }

    fun deleteNotif(notification: Notification): Int{
        val dataReadFuture: Future<Int> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                notif_Dao.deleteNotification(notification)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            -1
        }
        catch(e: InterruptedException){
            -1
        }
    }

    fun deleteTag(tag: Tag): Int{
        val dataReadFuture: Future<Int> = AppDatabase.databaseWriterExecutor.submit(
            Callable {
                tag_Dao.deleteTag(tag)
            })
        return try {
            while (!dataReadFuture.isDone) {
            }
            dataReadFuture.get()
        }catch(e: ExecutionException){
            -1
        }
        catch(e: InterruptedException){
            -1
        }
    }
}