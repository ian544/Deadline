package com.example.databaseset_up.DAO
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.databaseset_up.Entity.Task

interface TaskDao {
    @Query("SELECT * from task_table, list_table WHERE list_id = :list_ID")
    fun listAllTasksFromList(list_ID: Int): List<Task>

    @Update(Task::class)
    fun changeTask(task: Task)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertTask(task: Task)

    @Delete
    infix fun deleteTask(task: Task): Int

}