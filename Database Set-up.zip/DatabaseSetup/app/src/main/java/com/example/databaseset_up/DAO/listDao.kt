package com.example.databaseset_up.DAO

import androidx.lifecycle.LiveData
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.databaseset_up.Entity.list

interface listDao {
    @Query("SELECT * from list_table ORDER BY list_id ASC")
    fun listAllLists(): List<list>

    @Update(list::class)
    fun updateList(list: list)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertList(list: list)

    @Delete
    infix fun deleteList(list: list): Int

}